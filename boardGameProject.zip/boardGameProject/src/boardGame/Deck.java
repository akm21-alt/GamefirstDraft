package boardGame;
import java.util.ArrayList;
import java.util.Collections;

public class Deck {
	
    }
	
	
	
	
	
	
	
	// need an inheritance
	
	//Card = Superclass 
	// which are similar might have different function
	// special classes 
		// extra function
	// PLayer inheritence need to differentiate 
	// could be fields = score
	// implement 
// Create a class for each Card yellow, Blue 
	// Card - color and interger 
	// Regular 
	// 3 extra classes has special stuff 
	// random is outside player and deck and cards
	
	//Driver 
	//might game logic 
	// run small playable game with two players playing with a single easy round
	// they are playing both play when card fixed number of cards
	// dealer picks amount of cards and we will play that amount of cards dealer picked 
	// yes you got it
	// no you didn't get it 
	
	// focus on one class and one heritance class 
	
	//need to a README.file

