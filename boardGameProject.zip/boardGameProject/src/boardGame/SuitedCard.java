package boardGame;

public class SuitedCard extends Card {
	// saving time writing name and getName()
    private int value;
    //our 1-14 card numbers
    // helps us figure out who wins the trick
    //like does 10 beat a 12
    private String suit; // Parrot, Pirate Map, Treasure Chest, or Jolly Roger

    public SuitedCard(int value, String suit) {
    	// basically making the name
        super(suit + " " + value);
        //right value:  the number you just handed the code 
        this.value = value; //Take the number 14 and store it permanently in this card's value slot."
        //left  value :is the card's permanent memory.
        this.suit = suit;
    }

    public int getValue() { 
    	return value;
    	}
    public String getSuit() 
    { 
    	return suit; 
    	}
    
}
