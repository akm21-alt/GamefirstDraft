package boardGame;

public class GameDriver {
	public static void main(String[] args) {
		
        SkullKingGame game = new SkullKingGame();
        game.addPlayer("User");
        // just need to test whether we can play 2 people
        game.addPlayer("Computer(but not really it is still human and not Computer)");//our second player

        // Runs the first half of the game: 
        //Dealing and Bidding for Round 1 and 2
        game.startRound(1);
        game.startRound(2);
        
        System.out.println("\nBidding phase complete. Ready for trick taking!");
    }

}
