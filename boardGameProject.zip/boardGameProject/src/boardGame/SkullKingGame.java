package boardGame;

import java.util.ArrayList;
// create lists that can grow or shrink 
//(like a deck of cards or a list of players).
import java.util.Collections;
// kind a can't do shuffle without it
import java.util.List;
import java.util.Scanner;

public class SkullKingGame {
	
	//private means the "deck" can only be touched 
	//or changed by code inside the 
	//SkullKingGame class. This prevents 
	//outside code from accidentally deleting cards.
	private List<Card> deck;
	//This is a list that can only hold
	//objects of the type Card.
	// A list of Card
	//objects representing the physical deck.
	
    private List<Player> players;
    
    //A list of Player objects
    
    private Scanner scanner;

    //Constructor 
    //(Setting the Table)
    
    public SkullKingGame() {
        deck = new ArrayList<>();
        players = new ArrayList<>();
        scanner = new Scanner(System.in);
        
        //It initializes the lists 
        //so they aren't "null"
        
        initializeDeck();
        //immediately calls initializeDeck() 
        //to fill the box with cards.
    }
// Now we have to create the cards that go in the DECK
    private void initializeDeck() {
    	// In our game we have 4 suits
    	// each suit has number from 1-14
        String[] suits = {"Yellow", "Green", "Purple", "Black"};
        for (String suit : suits) {
        	// this outer loop goes through each suit
            for (int i = 1; i <= 14; i++) {
            	// this inner loop goes through numbers 1-14
                deck.add(new SuitedCard(i, suit)); 
                // so if you do the math 4 x 14  = 56 cards and ALL OF THAT
                // gets added to the deck list
            }
            // Card stuff is done :)
        }
    }

    public void addPlayer(String name) {
    	//void =  method performs an 
    	//action but returns nothing back to the caller. 
    	//(String name)
    	// you must provide a piece of text (the player's name).
    	
        players.add(new Player(name));
        //Why
        //new Player(name)This creates a new instance (an object) of the Player class, 
        //passing that name into the Player's own constructor.
        // players.add(...)This takes that brand-new Player object and 
        //puts it into the players list we created earlier.
    }
    
    // Now lets work on the Dealing 

    public void startRound(int roundNumber) {
    	//This parameter tells the method which 
    	//round is happening (Round 1, Round 2, etc.).
    	//This is important because in Skull King,  
    	//round number determines how many cards are dealt.
        System.out.println("\n--- Starting Round " + roundNumber + " ---");
        Collections.shuffle(deck);
        //Scanner obj = new Scanner(System.in);
        // this shuffle method acts like the physical one
        // without shuffling the card would be in the same order
        
        // Deal cards: Round 1 gets 1 card, Round 2 gets 2, etc. [5]
        for (Player p : players) {
        	// : in 
        	//players: The list you are looping through.
        	//For every Player object 
        	//(which we will call 'p' for now) 
        	//inside the 'players' list, run the following code." 
        	//It automates going through 
        	//Player 1, then Player 2, etc.
            p.clearHand();
            // Empties the player's hand from the last round
            
            for (int i = 0; i < roundNumber && roundNumber < 10; i++) {
            	// takes the "top card" off the deck
            	//and gives it to the player
                p.addCardToHand(deck.remove(0));
            }
        }
        // time for the next part: Bidding
        handleBidding(roundNumber);
      //roundNumber: passes the current round number as an Argument
    	//The bidding logic needs to know the round number to make sure 
    	//you don't bid 5 in a round where you only have 2 cards.
    	//
    }

    private void handleBidding(int roundNumber) {
    //  kept private because "bidding" is an internal game phase;
    //  it shouldn't be triggered by itself from outside the game logic.
        for (Player p : players) {
        	// After dealing the cards in the last  section,
        	//we now loop through every player again to ask them
        	//for their "bid" (how many tricks they think they will win).
            System.out.println(p.getName() + ", your hand: " + p.getHand());
            //getName : This calls a method on the current
            //player p to get their specific name ( ex:"Alice").
            //getHand: calls a method to show the
            //list of cards currently held by player p.
            int bid = -1;
            //Since a player can bid 0, we use -1 as a
            //"placeholder" to show that no valid bid has 
            //been entered yet. This allows the 
            //while loop that follows 
            //to start running.
            while (bid < 0 || bid > roundNumber) { 
            	//keeps asking the player for a number until they 
            	//provide a valid one (between 0 and the current round number).
                try {
                	//If you type "five" instead of "5,"
                	//
                    System.out.print("Enter your bid (0-" + roundNumber + "): ");
                   bid = Integer.parseInt(scanner.nextLine());
                } catch (NumberFormatException e) {
                	//catches that crash and prints a friendly warning instead.
                    System.out.println("Invalid input. Please enter a number.");
                }
            }
            p.setBid(bid);
        }
    }

}
