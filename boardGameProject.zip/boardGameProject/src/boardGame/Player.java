package boardGame;

import java.util.ArrayList;
import java.util.List;

public class Player {
	
	private String name;
    private List<Card> hand;
    private int bid;
    private int tricksWon;

    public Player(String name) {
        this.name = name;
        this.hand = new ArrayList<>();
        this.tricksWon = 0;
    }

    public void addCardToHand(Card card) 
    //Triggered during the "Deal" phase. 
    //This adds a card object to the player's
    //internal ArrayList.

    { 
    	hand.add(card); 
    }
    
    public List<Card> getHand() 
    //method that gets the 
   //current list of cards. 
    //This is key to display 
    //options to the player.

    { 
    	return hand;
    }
    
    public void setBid(int bid) 
    //This sets the "Bidding" phase logic. 
    //Each player must store their predicted 
    //number of wins before the first trick
    //of the round is played.

    { 
    	this.bid = bid;
    }
    
    public int getBid() 
    { 
    	return bid;
    }
    
    public void clearHand() 
    //"Ending a Round" phase.
    //This resets the player’s hand to a 
    //zero count state to prepare for
    //the next round.

    { 
    	hand.clear(); 
   
    	tricksWon = 0; 
    }
    
    public String getName() 
    {
    	return name; 
    }

}
