package boardGame;

public  class Card {
	// abstract because we can't just have A card
	// We'll need like  
	//a Suited Card, a Pirate, or the Skull King.
	// Example: Card c = new SuitedCard(); 
    private String name;

    public Card(String name) {
        this.name = name;
        //Take the name 
        //I just received in the 
        //parentheses and save it into
        //this object's permanent memory."
    }

    public String getName() {
        return name;
    }
// cause we know java will print out the address
    @Override
    public String toString() {
        return name;
    }
}